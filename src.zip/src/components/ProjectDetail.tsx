import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ReactNode } from "react";

interface Project {
  id: number;
  src: string;
  alt: string;
  title: string;
}

interface ProjectDetailProps {
  project: Project | null;
}

interface ProjectContent {
  description: string;
  secondParagraph: string | ReactNode;
  projectType: string;
  year: string;
  role: string;
  tools: string;
}

export default function ProjectDetail({
  project,
}: ProjectDetailProps) {
  // Default fallback if no project is provided
  if (!project) {
    return (
      <main className="pt-20 sm:pt-24 md:pt-32 pb-20 sm:pb-24 md:pb-32 px-3 sm:px-4 bg-background text-foreground">
        <div className="max-w-4xl mx-auto">
          <p className="text-base sm:text-lg font-normal text-foreground">
            Project not found.
          </p>
        </div>
      </main>
    );
  }

  // Project-specific content based on the project ID
  const getProjectContent = (
    project: Project,
  ): ProjectContent => {
    switch (project.id) {
      case 1:
        return {
          description:
            "Improvements on Bradesco Seguro's web search for healthcare providers.",
          secondParagraph:(
            <>
              I was the UX Lead responsible for interaction design and conduction of qualitative research such as user interviews and usability testing. Check it out here:{" "}
              <a
                href="https://www.bradescoseguros.com.br/clientes/produtos/plano-saude/consulta-de-rede-referenciada"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground hover:opacity-70 transition-opacity underline underline-offset-2"
              >
                Bradesco Healthcare Provider Search
              </a>
            </>
            ),
          projectType: "Healthcare Interface Design",
          year: "2023",
          role: "UX Lead & UX Researcher",
          tools: "Figma, Mural",
        };
      case 2:
        return {
          description:
            "Website redesign for Capemisa with focus on improved user experience and visual design.",
          secondParagraph:
            "I was responsible for the complete design system and visual identity, creating a cohesive digital presence.",
          projectType: "Website Design & Development",
          year: "2021",
          role: "Product Designer & Visual Designer",
          tools: "Adobe XD",
        };
      case 3:
        return {
          description:
            "This is a pilot project with Drex (Brazilian CBDC) in partnership with Giesecke+Devrient to enable payments without internet connection in remote areas in Brazil.",
          secondParagraph: (
            <>
              I was the Lead Product Designer in this project.
              The project was showcased in one of the biggest
              technology fairs in Brazil, BB Digital Week
              (BBDW). More information:{" "}
              <a
                href="https://www.bb.com.br/pbb/pagina-inicial/imprensa/n/67840/bb-e-gd-firmam-parceria-para-testar-pagamentos-offline-com-drex#/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground hover:opacity-70 transition-opacity underline underline-offset-2"
              >
                BB and G+D Offline Payment
              </a>
            </>
          ),
          projectType: "Banking Product Design",
          year: "2024",
          role: "Lead Product Designer & Visual Designer",
          tools: "Figma",
        };
      case 4:
        return {
          description:
            "WhatsApp bot conversational design for Oi, Brazil's telecommunications company.",
          secondParagraph:
            "I was the conversational designer responsible for projecting Joice's user flows and content writing.",
          projectType: "Conversational Design",
          year: "2021",
          role: "Conversational and Service Designer",
          tools: "Figma, Drawio",
        };
      default:
        return {
          description:
            "Conversational and service design with focus on user experience.",
          secondParagraph:
            "I was responsible for designing user-centered solutions with focus on accessibility and usability.",
          projectType: "Interface Design",
          year: "2024",
          role: "Product Designer",
          tools: "Figma, Adobe Creative Suite",
        };
    }
  };

  const content = getProjectContent(project);
  return (
    <main className="pt-20 sm:pt-24 md:pt-32 pb-20 sm:pb-24 md:pb-32 px-3 sm:px-4 bg-background text-foreground">
      <div className="max-w-4xl mx-auto">
        {/* Project Image */}
        <div className="w-full mb-6 sm:mb-8">
          <ImageWithFallback
            src={project.src}
            alt={project.alt}
            className="w-full h-auto rounded-none"
          />
        </div>

        {/* Project Information */}
        <div className="space-y-4 sm:space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-medium text-foreground mb-3 sm:mb-4">
              {project.title}
            </h2>
            <div className="text-base sm:text-lg font-normal text-foreground leading-relaxed space-y-3 sm:space-y-4">
              <p className="opacity-90">
                {content.description}
              </p>
              <p className="opacity-90">
                {typeof content.secondParagraph === "string"
                  ? content.secondParagraph
                  : content.secondParagraph}
              </p>
            </div>
          </div>

          {/* Project Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 md:gap-8 pt-4 sm:pt-6">
            <div className="space-y-1 sm:space-y-2">
              <h3 className="text-base sm:text-lg font-medium text-foreground">
                Project Type
              </h3>
              <p className="text-sm sm:text-base md:text-lg font-normal text-muted-foreground">
                {content.projectType}
              </p>
            </div>

            <div className="space-y-1 sm:space-y-2">
              <h3 className="text-base sm:text-lg font-medium text-foreground">
                Year
              </h3>
              <p className="text-sm sm:text-base md:text-lg font-normal text-muted-foreground">
                {content.year}
              </p>
            </div>

            <div className="space-y-1 sm:space-y-2">
              <h3 className="text-base sm:text-lg font-medium text-foreground">
                Role
              </h3>
              <p className="text-sm sm:text-base md:text-lg font-normal text-muted-foreground">
                {content.role}
              </p>
            </div>

            <div className="space-y-1 sm:space-y-2">
              <h3 className="text-base sm:text-lg font-medium text-foreground">
                Tools
              </h3>
              <p className="text-sm sm:text-base md:text-lg font-normal text-muted-foreground">
                {content.tools}
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
