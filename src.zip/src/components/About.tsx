export default function About() {
  return (
    <main className="pt-20 sm:pt-24 md:pt-32 pb-20 sm:pb-24 md:pb-32 px-3 sm:px-4 bg-background text-foreground">
      <div className="max-w-4xl mx-auto">
        <div>
          {/* Bio Description */}
          <div className="pt-4 sm:pt-6 md:pt-8">
            <div className="text-base sm:text-lg font-normal text-foreground leading-relaxed space-y-1">
              <p className="opacity-90">My name is Adriane Harumi Portella, I'm a BA in Visual Communication Design, product designer, design consultant and illustrator based in Rio de Janeiro.</p>
              <p className="opacity-90">I have 4 years of experience in the banking industry working with clients such as Bradesco and Banco do Brasil.</p>
              <p className="opacity-90">Feel free to contact me :)</p>
            </div>
          </div>

          {/* Location and Contact Info - Side by Side */}
          <div className="pt-6 sm:pt-8 grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
            {/* Location and Date */}
            <div className="space-y-2">
              <p className="text-base sm:text-lg font-normal text-muted-foreground">
               Rio de Janeiro ࿊
              </p>
              <p className="text-base sm:text-lg font-normal text-muted-foreground">
               Brazil, 2025
              </p>
            </div>

            {/* Contact Information */}
            <div className="space-y-2">
              <p className="text-base sm:text-lg font-normal text-muted-foreground">
               <a href="mailto:adrianeharumip@gmail.com" className="hover:text-foreground transition-colors">
                 → adrianeharumip@gmail.com
              </a>
              </p>
            
              <p className="text-base sm:text-lg font-normal text-muted-foreground">
                 <a 
                    href="https://www.linkedin.com/in/adriane-harumi/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-foreground transition-colors"
                  >
                    → Linkedin
                  </a>
              </p>
               <p className="text-base sm:text-lg font-normal text-muted-foreground">
                 <a 
                    href="https://www.instagram.com/harumiadriane" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-foreground transition-colors"
                  >
                    → Instagram
                  </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
