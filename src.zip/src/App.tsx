import { useState, useEffect } from 'react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Globe, Sun, Moon } from 'lucide-react';
import About from './components/About';
import ProjectDetail from './components/ProjectDetail';
import portfolioImage1 from 'figma:asset/d5bea866ce6d0ea92958b444ed032ba353f67394.png';
import portfolioImage2 from 'figma:asset/19ea0d339cce666ca211af21d2ac53b1aa7efd99.png';
import portfolioImage3 from 'figma:asset/d3b434fb6744ada4e3f877dd254fe4d4959cff18.png';
import portfolioImage4 from 'figma:asset/67bb91327e81915d7313c8b82de1c4aa110f359c.png';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'about' | 'project'>('home');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [selectedProject, setSelectedProject] = useState<any>(null);

  // Load theme from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'dark' | 'light' | null;
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  // Update document class and localStorage when theme changes
  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  // Mock gallery images - in a real implementation these would come from a CMS or API
  const galleryImages = [
    { id: 3, src: portfolioImage3, alt: 'Portfolio Image 3', title: 'Banco do Brasil - Offline Payment' },
    { id: 1, src: portfolioImage1, alt: 'Portfolio Image 1', title: 'Bradesco - Healthcare Provider Search' },
    { id: 2, src: portfolioImage2, alt: 'Portfolio Image 2', title: 'Capemisa - Website' },
    { id: 4, src: portfolioImage4, alt: 'Portfolio Image 4', title: 'Oi - WhatsApp Bot' },
  ];

  const handleImageClick = (imageId: number) => {
    // Find the clicked project and set it as selected
    const clickedProject = galleryImages.find(img => img.id === imageId);
    if (clickedProject) {
      setSelectedProject(clickedProject);
      setCurrentPage('project');
    }
  };

  const renderContent = () => {
    if (currentPage === 'about') {
      return <About />;
    }

    if (currentPage === 'project') {
      return <ProjectDetail project={selectedProject} />;
    }

    return (
      <div className="min-h-screen bg-background text-foreground font-sans">
        {/* Main Content Area */}
        <main className="pt-20 sm:pt-24 md:pt-32 pb-20 sm:pb-24 md:pb-32 px-3 sm:px-4">
          {/* Gallery Grid - Each Item on Different Line */}
          <div className="grid grid-cols-1 gap-3 sm:gap-4">
            {galleryImages.map((image, index) => (
              <div key={image.id} className="w-full relative group">
                <div 
                  className="cursor-pointer"
                  onClick={() => handleImageClick(image.id)}
                >
                  <ImageWithFallback
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-auto rounded-none transition-all duration-300 group-hover:brightness-40"
                  />
                  
                  {/* Hover Overlay with Project Name */}
                  <div className="absolute inset-0 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
                    <h3 className="text-white text-base sm:text-lg md:text-xl lg:text-2xl font-medium text-center px-2 sm:px-4">
                      {image.title}
                    </h3>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Top Right Navigation - Theme Toggle and About Link */}
      <div className="fixed top-0 right-0 z-50 p-3 sm:p-4">
        <div className="flex items-center gap-3 sm:gap-4 md:gap-6">
          <button 
            onClick={() => setCurrentPage('about')}
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl leading-[0.65] font-medium tracking-tight opacity-85 text-foreground hover:opacity-70 transition-opacity"
          >
            about
          </button>
          <button
            onClick={toggleTheme}
            className="text-foreground hover:opacity-70 transition-opacity"
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
          >
            {theme === 'dark' ? <Sun size={20} className="sm:w-6 sm:h-6" /> : <Moon size={20} className="sm:w-6 sm:h-6" />}
          </button>
        </div>
      </div>

      {/* Header Navigation - Pinned to Top */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-background">
        <div className="flex justify-start items-center p-3 sm:p-4">
          <button 
            onClick={() => setCurrentPage('home')}
            className="text-foreground hover:opacity-70 transition-opacity"
          >
            <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl leading-[0.65] font-medium tracking-tight opacity-85">
              Adriane Harumi ⊹₊⟡⋆
            </span>
          </button>
        </div>
      </header>

      {/* Render Current Page Content */}
      {renderContent()}

      {/* Footer - Pinned to Bottom */}
      <footer className="fixed bottom-0 left-0 right-0 z-40 bg-background border-t border-border">
        <div className="flex justify-between items-center p-3 sm:p-4">
          <div className="flex-shrink-0">
            <span className="text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl 2xl:text-5xl leading-[0.65] font-medium tracking-tight opacity-85 text-foreground">
              ©2025
            </span>
          </div>
          <div className="flex-1 text-right">
            <span className="text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl 2xl:text-2xl leading-[0.65] font-medium tracking-tight opacity-85 text-foreground">
              adrianeharumip@gmail.com
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}